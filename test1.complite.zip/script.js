function Get() {
    var arr = { key1: 'val1', key2: 'val2', key3: 'val3' };
    $.ajax({
        type: "POST",
        data:{
        get :'set',
        arr:arr
        },
        url:"/get.php",
        success: function(data){
            //alert(JSON.stringify(data));
            $('.getback').text(JSON.stringify(data));
        }
    });
    // Сделайте post запрос к файлу get.php. В запросе передайте массив "arr"
    // В запросе должно сработать условие: isset($_POST['get'])
    
}
