/*    $(document).ready(function() {
    // Обработчик ввода для поиска
    $(document).on('keyup', '#search', function() {
        var text = $(this).val().toLowerCase(); // Используем $(this) вместо повторного поиска
        var select = $('#sel_org');
        var options = select.find('option');

        if (options.length) {
            options.each(function() {
                var optionText = $(this).text().toLowerCase();
                $(this).toggle(optionText.includes(text) || $(this).is(':disabled'));
            });

            // Выделяем первую совпадение, если оно есть
            var firstMatch = options.filter(function() {
                return $(this).text().toLowerCase().includes(text) && !$(this).is(':disabled');
            }).first();
            if (firstMatch.length) {
                select.val(firstMatch.val());
            }
        }
    });

    // Обработчик изменения select
    $(document).on('change', '#sel_org', function() {
        console.log('бу');
        // Раскомментируйте и настройте, если нужно
        /*
        EXPORT_MODAL();
        let id_org = $("#sel_org").val();
        $.post(H_ARR['hos'] + '/catalog/adm/zk/get.php', {
            save_org: 1,
            zk: H_ARR['GET']['zk'],
            id_org: id_org
        }, function(json) {
            EXPORT_MODAL({ fade: 200 });
        }, 'json');
    });
});*/
$(document).ready(function() {
    const $search = $('#search');
    const $select = $('#sel_org');
    const $wrapper = $('.select-wrapper');

    // Фильтрация при вводе
    $search.on('input', function() {
        const filter = $(this).val().toLowerCase();
        const options = $select.find('option');

        options.each(function() {
            const optionText = $(this).text().toLowerCase();
            $(this).toggle(optionText.includes(filter) || $(this).is(':disabled'));
        });

        // Выделяем первое совпадение
        const firstMatch = options.filter(function() {
            return $(this).text().toLowerCase().includes(filter) && !$(this).is(':disabled');
        }).first();
        if (firstMatch.length) {
            $select.val(firstMatch.val());
        }
    });

    // Управление видимостью
    $search.on('focus', function() {
        $(this).css('z-index', '-1'); // Скрываем input под select
        $select.css('z-index', '0'); // Делаем select доступным
    });

    $select.on('blur', function() {
        // Возвращаем input на передний план после потери фокуса select
        setTimeout(function() {
            $search.css('z-index', '0');
            $select.css('z-index', '-1');
        }, 200); // Задержка для корректного закрытия select
    });

    // Обработчик изменения select
    $select.on('change', function() {
        console.log('бу');
        // Раскомментируйте, если нужно
        /*
        EXPORT_MODAL();
        let id_org = $select.val();
        $.post(H_ARR['hos'] + '/catalog/adm/zk/get.php', {
            save_org: 1,
            zk: H_ARR['GET']['zk'],
            id_org: id_org
        }, function(json) {
            EXPORT_MODAL({ fade: 200 });
        }, 'json');
        */
    });
});