<?php

/**
 * Description of config
 *
 * @author andreych
 */
class config {
    //put your code here
    public $HOST = '127.0.0.1';
    public $DBNAME = 'tests';
    public $USERDB = 'tester';
    public $PWDUSRBD ='DMj9K0aXXSx0UYT8';
}
 