<?php
/**
 * Description of User
 *
 * @author andreych
 */
class cUser {
    function logIn(){
        
    }
}
