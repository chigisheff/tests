<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Тест 4</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <script src="/jquery371.min.js"></script>
    <script src="/script.js"></script>
    
</head>

<body style="background: #333; color:#FFF; margin:0px;">
    <div style="position: relative; padding:40px;">

        <h1>Тестовая задача 4</h1>

        <div id="content">

            <br><br>
            <p>Поиск в select на jquery</p>
            <button><div style="position: relative; width:250px; background:#CCC; color:#930; text-align:center;">LogIn</div></button>

            <br><br>

            <div class="grid">
                <div class="item">
                    
                    <div class="select-wrapper">
                        <input type="text" id="search" placeholder="Поиск организации..." class="search-input">
                        <select id="sel_org" name="set[sk]" class="svg-arrow input_forma_new" size="5">
                            <option disabled="" value="">   </option>
                            <option value="1">ОргСтрой</option>
                            <option value="2">ООО «Вдолгстрой»</option>
                            <option value="3">СКИ (SKI)</option>
                            <option value="4" selected="">«Розовый фламинго»</option>
                            <option value="5">Иркутская Строительная Компания</option>
                            <option value="6">Новая орг</option>
                            <option value="7">ООО «Двойные кавычки»</option>
                            <option value="8">«вот такая»</option>
                            <option value="9">Valeriy</option>
                            <option value="10">ИП Одинцов</option>
                            <option value="11">a.kuzionov</option>
                            <option value="12">Jannat Buildings</option>
                            <option value="13">123</option>
                            <option disabled="" value="">---------------------</option>
                            <option value="0">Каталог в архиве</option>
                            <option disabled="" value="">   </option>
                        </select>
                    </div>

                </div>
                
            </div>

            <br><br>

            <div style="position: relative;">
                <div class="getback" style="position: relative; padding: 10px; background:#CCC; color:#000; box-shadow: 0 0 0 1px #999;"></div>
            </div>

            <br><br><br><br>
        </div>
    </div>
</body>

</html>